library(retry)

# тестовая функция 
fun <- function(p = 0) {
  
  x <- runif(1)
  
  if (runif(1) < 0.9) {
    
    print(paste0('X = ', x, ' is Error!'))
    
    Sys.sleep(p)
          
    stop("random error")
  }
  "Excellent"
}

# повторяем функци до тех пор пока она не выполнится
retry(fun(), when = "random error")

# добавим временной интервал между попытками
retry(fun(), when = "random error", interval = 2)

# ограничим количество попыток выполнения функции
retry(fun(), when = "random error", max_tries = 3)

# ограничим время выполнения функции
retry(fun(4), when = "random error", timeout = 2)

# проверяем результат выполнения выражения
# val это выражение которое мы проверяем
# cnd результат вычисления val
retry(fun(), until = function(val, cnd) val == "Excellent")

library(purrr)

# тестовая функция
div <- function(x, y) {
  
  if ( is.na(x) ) warning("X is NA")
  return(x / y)

}

# пробуем обработку через lapply
val <- list(1, 6, 3, NA, 'k', 3)
# тест
lapply(val, div, y = 2)

# ######### #
# safely    #
# ######### #
# разделит успешные результаты и ошибки
res <- lapply(val, safely(div), y = 2)

# разбить ошибкии корректные результаты по векторам
res <- res %>% transpose()

res$result # успешные результаты
res$error  # ошибки

# ######### #
# possibly  #
# ######### #
# данная функция заменит ошибки заданным значением
res <- lapply(val, possibly(div, 0), y = 2) 

# ######### #
# quietly   #
# ######### #
# перехватыет выводимые результаты, сообщения и предупреждения
val <- list(1, 6, 3, NA, 3)
res <- map(val, quietly(div), y = 2) %>% str